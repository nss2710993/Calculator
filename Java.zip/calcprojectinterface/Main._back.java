/**
The main class to start operation
*/
import io.*;
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) throws Exception
	{
		
		//CalcIOSingle sio = new CalcIOSingle();
		//CalcIOFile fio=new CalcIOFile();
		//CalcIOArray aio=new CalcIOArray();
		
		//CalcIOSingle sio = null;
		//CalcIOFile fio=null;
		//CalcIOArray aio=null;
		
		InterfaceCalcIO cio = null;
		
		//read propeties file to know which type of operation needed.
		//then create appropriate 
		
		Scanner sc=new Scanner(System.in);
		
		while(true)
		{
			String s;
			System.out.print("Single Input (s), File Input (f), Array Input (a), Quit (q) : ");
			s=sc.next();
			
			if("q".equals(s))
			{
				break;
			}
			else if("f".equals(s))
			{
				cio=new CalcIOFile();
				//fio.startOperations();
			}
			else if("s".equals(s))
			{
				cio = new CalcIOSingle();
				//sio.startOperations();
			}
			else if("a".equals(s))
			{
				cio=new CalcIOArray();
				//aio.startOperations();
			}
				cio.startOperations();
			}
			System.out.println("Exit Successfully");
	}
}