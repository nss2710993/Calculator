package io;
import java.util.Scanner;
public interface InterfaceCalcIO

{
	Scanner sc = new Scanner(System.in);
	void startOperations() throws Exception;
}