package processors;
/**
This class responsible for providing basic calculator operations
-, +, /, *
*/
public class NormalCalculator
{
	/**
	this method checks is valid operator is provided or not
	*/
	public boolean checkOp(char op)
	{
		if(op=='+' || op=='-' || op=='*' || op=='/'){}
            else return false; 
                return true;
	}
	 
	public int operate(int n1, int n2, char op)
	{
		 int r=0;
           if(op=='+')
           {
               r=add(n1,n2);
           }
           else if(op=='-')
           {
               r=subtract(n1,n2);
           }
           else if(op=='*')
           {
              r=multiply(n1,n2);
           }
           else if(op=='/')
           {
               r=divide(n1,n2);
           }

            return r;
	}

	public int add(int n1, int n2)
	{
		return n1 + n2;
	}

	public int subtract(int n1, int n2)
	{
		return n1-n2;
	}
	
	public int multiply(int n1, int n2)
	{
		return n1*n2;
	}

	public int divide(int n1, int n2)
	{
		return n1/n2;
	}

	
}