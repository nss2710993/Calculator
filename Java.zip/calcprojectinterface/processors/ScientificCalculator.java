package processors;
/**
This class responsible for providing basic calculator operations
-, +, /, *
*/
public class ScientificCalculator extends NormalCalculator
{
	/**
	this method checks is valid operator is provided or not
	*/
	@Override
	public boolean checkOp(char op)
	{
		boolean d=super.checkOp(op);
            if(d==true)
            {
                return true;
            }
            else if(op=='%' || op=='^')
			{
				return true;
			}

        return false;
	}
	 
	@Override 
	public int operate(int n1, int n2, char op)
	{
		 int r;
        r=super.operate(n1, n2, op);
        if(op=='^')
        {
            r=power(n1,n2);
        }
        else if(op=='%')
        {
            r=mode(n1,n2);
        }
        return r;
	}

	public int power(int n1, int n2)
	{
			int p=1;
			if(n2==0)
			{
				return p;
			}
			else if(n2==1)
			{
				p=n1;
				return p;
			}
		for(int i=0;i<n2;i++)
		{
			p=p*n1;
		}
        
    return p;
	}
	
	int mode(int a, int b)
    {
        return a%b;
    }
	
	

}