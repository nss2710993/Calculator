public class CalculatorBasic
{

	    public static int add(int num1,int num2)
		{
			return num1 + num2;
		}
		public static int subtract(int num1,int num2)
		{
			return num1 - num2;
		}
		
		public static int multiply(int num1,int num2)
		{
			return num1 * num2;
		}

		public static int division(int num1,int num2)
		{
			if( num2 != 0)
				return num1 / num2;
			else 
				return 0;
		}
	
	public static void main(String[] args)
	{
	
		
		System.out.println("Result of addition: "+add(5,2));
		
		
		System.out.println("Result of subtraction: " +subtract(5,2));
		
		
		System.out.println("Result of multiplication: " +multiply(5,2));
		
		
		System.out.println("Result of division: "+division(6,2));
	}

}