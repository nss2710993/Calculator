import java.util.Scanner;
public class CalcArray //Test Driven Development
{
	public static void main(String[] args)
	{
		//Calculator c = new CalculatorChild();
		int res = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Five Numbers:");
		String num1 = sc.nextLine();
		System.out.println("Enter Five Numbers:");
		String num2 = sc.nextLine();
		System.out.println("Enter operators: ");
		String operator = sc.nextLine();
		
		String[] num1string = num1.split(",");
		int num1arraylength = num1string.length;
		int num1array[] = new int[num1arraylength];
		for(int i = 0;i < num1arraylength;i++)
		{
			num1array[i] = Integer.parseInt(num1string[i]);
		}
		
		String[] num2string = num2.split(",");
		int num2arraylength = num2string.length;
		int num2array[] = new int[num2arraylength];
		for(int i = 0;i < num2arraylength;i++)
		{
			num2array[i] = Integer.parseInt(num2string[i]);
		}
		
		String[] operatorstring = operator.split(",");
		int operatorarraylength = operatorstring.length;
		
		int small = 0;
		
		if(operatorarraylength<num1arraylength)
		{
			small = operatorarraylength;
		}
		else
		{
			small = num1arraylength;
		}
		if(small > num2arraylength)	
		{
			small = num2arraylength;
		}
		//int operatorarray[] = new int[operatorarraylength];
		//for(int i = 0;i < operatorarraylength;i++)
		//{
		//	operatorarray[i] = Integer.parseInt(operatorstring[i]);
		//}
		//for(String n1:num1arr)
		//{
		//	System.out.println(num1array);
		//}
		//for(String n2:num2arr)
		//{
		//	System.out.println(num2array);
		//}
		//for(String op:operatorstring)
		//{
		//	System.out.println(operatorstring);
		//}
		
		for(int i=0;i<small;i++)
		{
			if("+".equals(operatorstring[i]))
			{
				res=num1array[i] + num2array[i];
			}
			else if("-".equals(operatorstring[i]))
			{
				res=num1array[i] - num2array[i];
			}
			else if("*".equals(operatorstring[i]))
			{
				res = num1array[i] * num2array[i];
			}
			else if("/".equals(operatorstring[i]))
			{
				res=num1array[i]/num2array[i];
			}
					
			System.out.println("Result: of"+operatorstring[i]+"is "+res);
					
			}
		
		
	}
}