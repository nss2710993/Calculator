/**
The main class to start operation
*/
import io.*;
import processors.*;
import utilities.*;
import java.util.Scanner;
import java.io.IOException;


public class Main
{
	public static void main(String[] args)
	{
		Scanner scs= new Scanner(System.in);
		AbstractCalcIO cio = null;
			//read properties file to know which type of operation needed.
			//then create appropriate class based on that.
		
		
		
			try {
				String opm = PropertyReader.getProperty("config.properties","opmode");
				System.out.println("Go inp class name:" + opm);
			//ge he class obec from he name of he inp class
				Class c = Class.forName(opm);
				
				Object ioobj = c.newInstance();
				cio = (AbstractCalcIO) ioobj;
				if(cio != null)
				{
					cio.startOperations();
				}	

			} catch (Exception ex) {
				System.out.println("Error creating calculator: " + ex.getMessage());
			}

			// System.out.println("q for quit & c for continue");
			// char inn = scs.nextLine().charAt(0);
			// if(inn == 'q'){
			// 	break;
			// }
			// if(inn == 'c'){
			// 	continue;
			// }
		
	}
}