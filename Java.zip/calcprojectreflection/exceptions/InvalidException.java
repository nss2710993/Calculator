package exceptions;

public class InvalidException extends Exception{

	public InvalidException(String s){
		
		super(s);
	}
}