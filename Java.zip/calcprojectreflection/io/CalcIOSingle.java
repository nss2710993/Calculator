package io;
/**
This is the class 
whee actual IO starts.  But it only accepts
single number at a time and an opeatior to work
*/
import processors.*;
import exceptions.*;
import utilities.*;
import java.io.IOException;


public class CalcIOSingle extends AbstractCalcIO
{
	
		//read properties file to know which type of operation needed.
		//then create appropriate class based on that.
	@Override
	public void startOperations() throws Exception
	{
		
		int num1, num2;
		NormalCalculator calc = getCalculator();
		if(calc == null )
		{
			return;
		}

		if(calc != null){

			while(true)
			{
				System.out.print("Enter 1st number: ");
				while (!scs.hasNextInt()){
					System.out.println("Input must be the number");
					System.out.print("Enter 1st number: ");
					scs.next();
				}
				num1 = scs.nextInt();
					
				System.out.print("Enter 2nd number: ");
				while (!scs.hasNextInt()){
					System.out.println("Input must be the number");
					System.out.print("Enter 1st number: ");
					scs.next();
				}
				num2 = scs.nextInt();
				
				System.out.print("Choose operator from (+ - X / ^): ");
				char op=scs.next().charAt(0);
				if(op == 'q')
				{
					break;
				}
				boolean b1 = calc.checkOp(op);

				while (b1 == false){
					System.out.println("Your operator is wrong. Try again.");
					System.out.print("Choose operator from (+ - X / ^): or 'q' for exit");
					op = scs.next().charAt(0);
					b1 = calc.checkOp(op);
				}

				try{
					int result = calc.operate(num1, num2, op);
					System.out.println("Your answer is "+result);
				}
				catch(InvalidException ie){
					System.out.println(ie);
				}
				catch(ArithmeticException ae){
					System.out.println(ae);
				}
			}
		}
	}

	
}