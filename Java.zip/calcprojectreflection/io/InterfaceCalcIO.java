package io;
import java.util.Scanner;

public interface InterfaceCalcIO
{
	Scanner scs= new Scanner(System.in);
	void startOperations() throws Exception;
}
