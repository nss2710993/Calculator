package io;
/**
This is the class 
whee actual IO starts.  It accepts two sets of numbers in comma separated form.
Then takes a comma-separated list of operators 
*/
import java.util.*;
import java.lang.*;
import java.io.*;
import processors.*;
import utilities.*;

public class CalcIOFile extends AbstractCalcIO
{
	//InterfaceCalculator calc = null;
        //read properties file to know which type of operation needed.
        //then create appropriate class based on that.
    @Override
	public void startOperations() throws Exception
	{

        NormalCalculator calc = getCalculator();
        if(calc == null )
        {
            return;
        }

        if(calc != null){

    		String fileName = "data.txt";
    		String num1 = null, num2 = null, op = null;

    		try{
    			FileReader fileReader = new FileReader(fileName);
    			BufferedReader bufferedReader = new BufferedReader(fileReader);

    			while(true) {
    				num1 = bufferedReader.readLine();
                    num2 = bufferedReader.readLine();
                    op = bufferedReader.readLine();

                    if(num1 == null || num2 == null || op == null){
                        break;
                    }
                    
                    String[] arrOfNum1 = num1.split(",");
                    String[] arrOfNum2 = num2.split(",");
                    String[] arrOfOps = op.split(",");

                    //Integer [] intArray1 = new Integer[arrOfNum1.length];
                    //Integer [] intArray2 = new Integer[arrOfNum2.length];
                    int sm=0;
                    int ar1 = arrOfNum1.length;
                    int ar2 = arrOfNum2.length;
                    int arCh = arrOfOps.length;

                    if(arCh<ar1 && arCh<ar2)
                    {
                        sm = arCh;
                    }
                    else if(ar1<ar2)
                    {
                        sm = ar1;
                    }
                    else{
                        sm = ar2;
                    }

                    int n1 = 0;
                    int n2 = 0;
                    char opr = 0;
                    int result=0;
                    System.out.println("The result for each data set : "); 
                    for(int i= 0; i < sm; i++)
                    {
                        try{
                            //intArray1[i] = Integer.parseInt(arrOfNum1[i].trim());
                            n1 = Integer.parseInt(arrOfNum1[i].trim());
                            n2 = Integer.parseInt(arrOfNum2[i].trim());
                            opr = arrOfOps[i].trim().charAt(0);
                            boolean b1 = calc.checkOp(opr);
                            if(b1 == true)
                            {
                                result = calc.operate(n1, n2, opr);
                                System.out.println(result); 
                            }else{
                                System.out.println("invalid operation");
                            }
                            
                        }
                        catch(Exception e){
                            System.out.println("Bad Inputed.");
                            continue;
                        }
                       
                    }
                   	
                } 

                bufferedReader.close();
    		}
    		catch(FileNotFoundException ex) {
                System.out.println("Unable to open file '" + fileName + "'");                
            }
            catch(IOException ex) {
                System.out.println("Error reading file '" + fileName + "'");                  
            }
        }
	}

    
}