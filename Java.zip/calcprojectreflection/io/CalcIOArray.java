package io;
/**
This is the class 
whee actual IO starts.  It accepts two sets of numbers in comma separated form.
Then takes a comma-separated list of operators 
*/
import java.util.*;
import java.lang.*;
import processors.*;
import exceptions.*;
import utilities.*;
import java.io.IOException;

public class CalcIOArray extends AbstractCalcIO
{
	//InterfaceCalculator calc = null;
        //read properties file to know which type of operation needed.
        //then create appropriate class based on that.
    @Override
	public void startOperations() throws Exception
	{
        NormalCalculator calc = getCalculator();
        if(calc == null )
        {
            return;
        }

        if(calc != null){

    		System.out.print("Enter 1st number array : ");
            String str1 = scs.next();
            String[] arrOfStr1 = str1.split(",");

            System.out.print("Enter 2nd number array : ");
            String str2 = scs.next();
            String[] arrOfStr2 = str2.split(",");

            System.out.print("Enter operator array : ");
            String char1 = scs.next();
            String[] arrayOfchar1 = char1.split(",");
            
            int sm=0;
            int ar1 = arrOfStr1.length;
            int ar2 = arrOfStr2.length;
            int arCh = arrayOfchar1.length;

            if(arCh<ar1 && arCh<ar2)
            {
                sm = arCh;
            }
            else if(ar1<ar2)
            {
                sm = ar1;
            }
            else{
                sm = ar2;
            }

            int n1 = 0;
            int n2 = 0;
            char opr = 0;
            int result=0;
            System.out.println("The result for data set : "); 
            for(int i= 0; i < sm; i++)
            {
                try{
                    n1 = Integer.parseInt(arrOfStr1[i]);
                    n2 = Integer.parseInt(arrOfStr2[i]);
                    opr = arrayOfchar1[i].charAt(0);

                    boolean b1 = calc.checkOp(opr);
                    if(b1 == true)
                    {
                        result = calc.operate(n1, n2, opr);
                        System.out.println(result); 
                    }else{
                        System.out.println("invalid operation");
                    }           
                }
                catch(Exception e){
                    System.out.println("Bad Inputed.");
                    continue;
                }           
            }
        }
    } 

    
}