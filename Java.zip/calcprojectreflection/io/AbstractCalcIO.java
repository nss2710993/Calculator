package io;
import utilities.*;
import processors.*;
import java.io.IOException;
import java.util.Scanner;


public abstract class AbstractCalcIO
{
	Scanner scs= new Scanner(System.in);

	public NormalCalculator getCalculator()
	{
		NormalCalculator calc = null;
		try
		{
			String opm = PropertyReader.getProperty("config.properties","calcmode");

			if("nc".equalsIgnoreCase(opm))
			{
				calc = new NormalCalculator();
			}
			else if("sc".equalsIgnoreCase(opm))
			{
				calc = new ScientificCalculator();
			}
			else{
				System.out.println("Invalid operation mode specified in properties file.");
			}
		}catch (IOException ex){
			System.out.println("Error creating calculator: " + ex.getMessage());
		}
		return calc;

	}

	public abstract void startOperations() throws Exception;
}