package processors;
/**
This class responsible for providing basic calculator operations
-, +, /, *
*/

import java.lang.*;
import exceptions.*;
import processors.*;


public class ScientificCalculator extends NormalCalculator implements InterfaceCalculator
{
	/**
	this method checks is valid operator is provided or not
	*/
	@Override
	public boolean checkOp(char op)
	{
		boolean returnValue = super.checkOp(op);
		if(returnValue){
			return true;
		}
		else if(op == '^' || op == '%'){
			returnValue = true;
		}else{
			returnValue = false;
		}
		return returnValue;
	}
	 
	@Override 
	public int operate(int n1, int n2, char op) throws InvalidException, ArithmeticException
	{
		int r=0;
		try
		{
			r = super.operate(n1, n2, op);
		}
		catch(ArithmeticException ae)
		{
			throw ae;
		}
		catch(InvalidException ie)
		{
			if(op=='^')
			{
				r=power(n1,n2);
			}
			else
			{
				throw new InvalidException("your operator is wrong.");
			}
		}
					
			return r;
	}

	public int power(int n1, int n2)
	{
		int result=1;
		for(int i=0; i<n2; i++){
			result = result*n1;
		}
		return result;
	}

}