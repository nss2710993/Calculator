package processors;
import exceptions.*;

public interface InterfaceCalculator
{
	boolean checkOp(char op);
	int operate(int n1, int n2, char op) throws InvalidException, ArithmeticException;
}