package processors;
/**
This class responsible for providing basic calculator operations
-, +, /, *
*/

import java.lang.*;
import exceptions.*;
import processors.*;


public class NormalCalculator implements InterfaceCalculator
{
	/**
	this method checks is valid operator is provided or not
	*/
	public boolean checkOp(char op)
	{
		boolean returnValue;

		if(op == '+' || op == '-' || op == '*' || op == '/'){
			returnValue = true;
		}else{
			returnValue = false;
		}
		return returnValue;
	}
	 
	public int operate(int n1, int n2, char op) throws InvalidException, ArithmeticException
	{
		int r=0;
		if(op=='+')
		{
			r=add(n1,n2);
		}
		else if(op=='-')
		{
			r=subtract(n1,n2);
		}
		else if(op=='*')
		{
			r=multiply(n1,n2);
		}
		else if(op=='/')
		{
				
			r=divide(n1,n2);
		}
		else
		{
			throw new InvalidException("Invalid operator");
		}
		return r;
	}

	public int add(int n1, int n2)
	{
		return n1 + n2;
	}

	public int subtract(int n1, int n2)
	{
		return n1-n2;
	}
	
	public int multiply(int n1, int n2)
	{
		return n1*n2;
	}

	public int divide(int n1, int n2)
	{
		return n1/n2;
	}

	
}