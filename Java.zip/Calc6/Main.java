/**
The main class to start operation
*/
import utilities.*;
import io.*;
import java.util.Scanner;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
public class Main
{
	public static void main(String[] args) throws Exception
	{
		
		//CalcIOSingle sio = new CalcIOSingle();
		//CalcIOFile fio=new CalcIOFile();
		//CalcIOArray aio=new CalcIOArray();
		
		//CalcIOSingle sio = null;
		//CalcIOFile fio=null;
		//CalcIOArray aio=null;
		
		InterfaceCalcIO cio = null;
		
		//read propeties file to know which type of operation needed.
		//then create appropriate class based on that
		
		Properties prop = new Properties();
		InputStream input = null;

	try {

		//input = new FileInputStream("config.properties");

		// load a properties file
		//prop.load(input);

		// get the property value and print it out
		String opm = PropertyReader.getProperty("config.properties","opmode");
		if("s".equalsIgnoreCase(opm))
		{
			cio = new CalcIOSingle();
		}
		else if("a".equalsIgnoreCase(opm))
		{
			cio=new CalcIOArray();
		}
		else if("f".equalsIgnoreCase(opm))
		{
			cio=new CalcIOFile();
		}
		else
		{
			System.out.println("Invalid Operation Mode Specified in Properties File");
		}
		if(cio !=null)
			cio.startOperations();
	}
	catch (IOException ex) {
		System.out.println("Error Reading Properties File:" + ex.getMessage());
	
	}
}
}

/*The main class to start operation

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import io.*;
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) throws Exception
	{
		
		//CalcIOSingle sio = new CalcIOSingle();
		//CalcIOFile fio=new CalcIOFile();
		//CalcIOArray aio=new CalcIOArray();
		
		//CalcIOSingle sio = null;
		//CalcIOFile fio=null;
		//CalcIOArray aio=null;
		
		InterfaceCalcIO cio = null;
		
		//read propeties file to know which type of operation needed.
		//then create appropriate class based on that
		
		Properties prop = new Properties();
		InputStream input = null;

	try {

		input = new FileInputStream("config.properties");

		// load a properties file
		prop.load(input);

		// get the property value and print it out
		String opm = prop.getProperty("opmode");
		if("s".equalsIgnoreCase(opm))
		{
			cio = new CalcIOSingle();
		}
		else if("a".equalsIgnoreCase(opm))
		{
			cio=new CalcIOArray();
		}
		else if("f".equalsIgnoreCase(opm))
		{
			cio=new CalcIOFile();
		}
		else
		{
			System.out.println("Invalid Operation Mode Specified in Properties File");
		}
		if(cio !=null)
			cio.startOperations();
	}
	catch (IOException ex) {
		ex.printStackTrace();
	} finally {
		if (input != null) {
			try {
				input.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
}*/