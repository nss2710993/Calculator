/**
The main class to start operation
*/
import io.*;

public class Main
{
	public static void main(String[] args)
	{
		//CalcIOSingle cio = new CalcIOSingle();
		
		CalcIOFile cio = new CalcIOFile();
		cio.startOperations();
	}
}