package processors;
/**
This class responsible for providing basic calculator operations
-, +, /, *
*/
//import java.lang.*;
public class NormalCalculator
{
	/**
	this method checks is valid operator is provided or not
	*/
	public boolean checkOp(char op)
	{
		//add logic here
		if(op=='+' || op=='-' || op=='*' || op=='/')
		{            
		    return true;
        }
        else return false; 

	}
	 
	public int operate(int n1, int n2, char op)
	{
		 //check what type of operation is needed.
		int result = 0;
		if (op == '+') 
		{
			result = add(n1,n2);
		}
		else if (op == '-') 
		{
			result = subtract(n1,n2);
		}
		else if (op == '*') 
		{
			result = multiply(n1,n2);
		}		
		else if (op == '/') 
		{
			result = divide(n1,n2);
		}
		return result;
	}

	public int add(int n1, int n2)
	{
		return n1 + n2;
	}

	public int subtract(int n1, int n2)
	{
		return n1 - n2;
	}
	
	public int multiply(int n1, int n2)
	{
		return n1 * n2;
	}

	public int divide(int n1, int n2)
	{
		return n1/n2;
	}

	
}

/*package processor;
public class Calculator
{
	public boolean checkops(char c) throws Exception
    {
        if(c=='+' || c=='-' || c=='*' || c=='/')
		{            
		    return true;
        }
        else return false; 
    }
	public double result1(double num1, double num2, char c )
	{
		double result = 0;
		if (c == '+') 
		{
			result = add(num1,num2);
		}
		else if (c == '-') 
		{
			result = sub(num1,num2);
		}
		else if (c == '*') 
		{
			result = multiply(num1,num2);
		}		
		else if (c == '/') 
		{
			result = div(num1,num2);
		}
		return result;
	}
	public double add(double a,double b)
	{
		return a + b;
	}
	public double sub(double a,double b)
	{
		return a - b;
	}
	public double multiply(double a,double b)
	{
		return a * b;
	}
	public double div(double a,double b)
	{
		/*if( b == 0)
		{	
			return 0;
		}*/
	//	return a/b;
	//}

//}