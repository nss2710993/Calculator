package processors;
/**
This class responsible for providing basic calculator operations
-, +, /, *
*/
//import java.lang.*;

public class ScientificCalculator extends NormalCalculator
{
	/**
	this method checks is valid operator is provided or not
	*/
	@Override
	public boolean checkOp(char op) //throws Exception
	{
		//add logic here
		boolean operator = super.checkOp(op);
            if(operator == true)
            {
                return true;
            }
            else
            {
            if(op=='%' || op=='^')
				{return true;}/*
            else throw new Exception("Invalid Operator!");
            }*/
			}
			return false;
	}
	
	 
	@Override 
	public int operate(int n1, int n2, char op)
	{
		 //check what type of operation is needed.
		int result = 0;
        result = super.operate(n1, n2, op);
        if(op=='^')
        {
            result = power(n1,n2);
        }
        else if(op=='%')
        {
            result = mod(n1,n2);
        }
        return result;
	}

	public int mod(int n1,int n2)
	{
		return n1 % n2;
	}
	public int power(int a, int b)
	{
		//add logic
		//if power is zero then return 1
		//if base is 0, then return zero
		//if power is negative, then return ??
		int p = 1;
        if(b == 0) 
		{
			return p;
		}
		else if (b == 1) 
		{
            p = a;
			return p;
        }
		for(int i=0;i<b;i++)
		{
            
            p *= a; 
        }
        return p;
		
		/*int res = 1;
    int i1 = 31 - Integer.numberOfLeadingZeros(p); // highest bit index
    for (int i = i1; i >= 0; --i) {
        res *= res;
        if ((p & (1<<i)) > 0)
            res *= a;
    }
    return res;
	
		 /*if (n == 0)
            return 1;
        if (n == 1)
            return x;
        if (n < 0) { // always 1^xx = 1 && 2^-1 (=0.5 --> ~ 1 )
            if (x == 1 || (x == 2 && n == -1))
                return 1;
            else
                return 0;
        }
        if ((n & 1) == 0) { //is even 
            int num = pow(x * x, n / 2);
            if (num > Integer.MAX_VALUE) //check bounds
                return Integer.MAX_VALUE; 
            return (int) num;
        } else {
            int num = x * pow(x * x, n / 2);
            if (num > Integer.MAX_VALUE) //check bounds
                return Integer.MAX_VALUE;
            return (int) num;
        }*/
		//int power = 1;
        //    for(int c=0;c<b;c++)
        //    power*=a;
        //    return power;
		
		/*if ( b == 0)        return 1;
		if ( b == 1)        return a;
		if (isEven( b ))    return     pow ( a * a, b/2); //even a=(a^2)^b/2
		else                return a * pow ( a * a, b/2); //odd  a=a*(a^2)^b/2
		/*int p = 1;
		for(int i = 1;i < n2;i++)
			p = p * n1;
		return p;*/
		
	}

}


/*
package processor;
public class ScientificCalculator extends Calculator
{
	@Override
    public boolean checkops(char c) throws Exception
        {
            boolean operator = super.checkops(c);
            if(operator == true)
            {
                return true;
            }
            else
            {
            if(c=='%' || c=='^'){return true;}
            else throw new Exception("Invalid Operator!");
            }
        
        }
		
	@Override
    public double result1(double num1, double num2, char c)
    {
        double result = 0;
        result = super.result1(num1, num2, c);
        if(c=='^')
        {
            result = java.lang.Math.pow(num1,num2);
        }
        else if(c=='%')
        {
            result = mod(num1,num2);
        }
        return result;
    }
	
	public double mod(double a,double b)
	{
		return a % b;
	}
	/*int power(int a,int b)
    {
        for(int num1 = 1;num1 < num2;num1++)
        {
            num1 *= num1;
        }
		return num1;
    }*/
//}