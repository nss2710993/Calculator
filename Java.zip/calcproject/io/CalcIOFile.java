package io;
/**
This is the class 
whee actual IO starts.  It accepts two sets of numbers in comma separated form.
Then takes a comma-separated list of operators 
*/

import processors.*;
import java.util.Scanner;
import java.io.*;
import java.lang.*;

public class CalcIOFile
{
	Scanner sc= new Scanner(System.in);
	ScientificCalculator sccalc = new ScientificCalculator();
	NormalCalculator normalcalc = new NormalCalculator();
	public void startOperations()
	{
		//do operations here for taking one number at a time
		
        // The name of the file to open.
        String fileName = "calcdata.txt";

        // This will reference one line at a time
        String line = null;

        try 	{
            // FileReader reads text files in the default encoding.
            FileReader fileReader = 
                new FileReader(fileName);

            // Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader = 
                new BufferedReader(fileReader);

            while(true) 
			{
				//read three lines and put them in three different variables
				//check if any of those lines is null
				//if null, do a break to get out of loop
				//if not null then process each line 
				//following logic in the CalcIOArray file.
				
				String num1 = bufferedReader.readLine();
                //System.out.println(line);
				int res = 0;
			/*Scanner sc = new Scanner(System.in);
			System.out.println("Enter Five Numbers:");
			String num1 = sc.nextLine();
			System.out.println("Enter Five Numbers:");
			String num2 = sc.nextLine();
			System.out.println("Enter operators: ");
			String operator = sc.nextLine();*/
			String num2 = bufferedReader.readLine();
			String operator = bufferedReader.readLine();
			String[] num1string = num1.split(",");
			int num1arraylength = num1string.length;
			int num1array[] = new int[num1arraylength];
			//for(int i = 0;i < num1arraylength;i++)
			//{
			//	num1array[i] = Integer.parseInt(num1string[i]);
			//}
			
			String[] num2string = num2.split(",");
			int num2arraylength = num2string.length;
			int num2array[] = new int[num2arraylength];
			//for(int i = 0;i < num2arraylength;i++)
			//{
			//	num2array[i] = Integer.parseInt(num2string[i]);
			//}
			
			String[] operatorstring = operator.split(",");
			int operatorarraylength = operatorstring.length;
			
			int small = Math.min(operatorarraylength, Math.min(num1arraylength, num2arraylength));
			
			/*if(operatorarraylength<num1arraylength)
			{
				small = operatorarraylength;
			}
			else
			{
				small = num1arraylength;
			}
			if(small > num2arraylength)	
			{
				small = num2arraylength;
			}*/
			//int operatorarray[] = new int[operatorarraylength];
			//for(int i = 0;i < operatorarraylength;i++)
			//{
			//	operatorarray[i] = Integer.parseInt(operatorstring[i]);
			//}
			//for(String n1:num1arr)
			//{
			//	System.out.println(num1array);
			//}
			//for(String n2:num2arr)
			//{
			//	System.out.println(num2array);
			//}
			//for(String op:operatorstring)
			//{
			//	System.out.println(operatorstring);
			//}
			//int[] num1array =  new int[small];
			//int[] num2array = new int[small];
			for(int i=0;i<small;i++)
			{
				
				try
				{
					num1array[i] = Integer.parseInt(num1string[i]);
				}
				  catch(Exception e)
				  {
					  System.out.println("Inputed ("+num1string[i]+") Invalid Number!");
					  continue;
				  }
                                  
                try
				{
					num2array[i] = Integer.parseInt(num2string[i]);
				}
				  catch(Exception e)
				  {
					  System.out.println("Inputed ("+num2string[i]+") Invalid Number!");
					  continue;
				  }

				  boolean d=sccalc.checkOp(operatorstring[i].charAt(0));
				  if(d==false)
				  {
					  System.out.println("inputed ("+operatorstring[i]+") Invalid Operator!");
					  continue;
				  }
			  
			  try{
			  res=sccalc.operate(num1array[i],num2array[i],operatorstring[i].charAt(0));
			  System.out.println(num1array[i]+operatorstring[i]+num2array[i]+"= "+res);
			  }
			  catch(Exception e)
			  {
				  System.out.println("Error: "+e.getMessage());
			  }
			  }

				
				
				/*try
				{
					num1array[i]=Integer.parseInt(num1string[i]);
				}
				  catch(Exception e)
				  {
					  System.out.println("Inputed ("+num1string[i]+") Invalid Number!");
					  continue;
				  }
                                  
                try
				{
					num2array[i]=Integer.parseInt(num2string[i]);
				}
				  catch(Exception e)
				  {
					  System.out.println("Inputed ("+num2string[i]+") Invalid Number!");
					  continue;
				  }

				  boolean d=sccalc.checkOp(operatorstring[i].charAt(0));
				  if(d==false)
				  {
					  System.out.println("inputed ("+operatorstring[i]+") Invalid Operator!");
					  continue;
				  }

				if("+".equals(operatorstring[i]))
				{
					res=num1array[i] + num2array[i];
				}
				else if("-".equals(operatorstring[i]))
				{
					res=num1array[i] - num2array[i];
				}
				else if("*".equals(operatorstring[i]))
				{
					res = num1array[i] * num2array[i];
				}
				else if("/".equals(operatorstring[i]))
				{
					res=num1array[i]/num2array[i];
				}
						
				System.out.println("Result: of"+operatorstring[i]+"is "+res);*/
						
			}
		
		
	}
               

            // Always close files.
            //bufferedReader.close();         
        catch(FileNotFoundException ex) {
            System.out.println(
                "Unable to open file '" + 
                fileName + "'");                
        }
        catch(IOException ex) {
            System.out.println(
                "Error reading file '" 
                + fileName + "'");                  
            // Or we could just do this: 
            // ex.printStackTrace();
        }
	}
}