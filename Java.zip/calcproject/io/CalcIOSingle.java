package io;
/**
This is the class 
whee actual IO starts.  But it only accepts
single number at a time and an opeatior to work
*/

import processors.*;
import java.util.Scanner;

public class CalcIOSingle
{
	Scanner sc = new Scanner(System.in);
	ScientificCalculator sccalc = new ScientificCalculator();
	NormalCalculator normalcalc = new NormalCalculator();
	public void startOperations()
	{
		//do operations here for taking one number at a time
	/*	ScientificCalculator c = new ScientificCalculator();
	Scanner sc = new Scanner(System.in);*/
	char operator;
	int num1, num2, result;
	while (true)
	{	//try
		//{
		System.out.println("Enter the operator for the operation you want to do or press 'Q' for exit:");
		operator = sc.next().charAt(0);
		if (operator == 'Q') break;
		boolean validOperator =	sccalc.checkOp(operator);
		if (!validOperator )
		{
			System.out.println("Invalid Operator");
            continue;
		}
		//}	
		//catch(Exception e)
        //{
		//	System.out.println(e.getMessage());
        //    continue;
		//}
		System.out.println("Enter number 1: ");
		while(!sc.hasNextInt())
        {
			sc.next();
            System.out.println("Invalid Number! ");
            System.out.print("Enter 1st Number: ");
        }
		num1 = sc.nextInt();
			
		System.out.println("Enter number 2: ");
			while(!sc.hasNextInt())
            {
              sc.next();
              System.out.println("Invalid Number! ");
              System.out.print("Enter 1st Number: ");
            }
			num2 = sc.nextInt();
			
			/*result = c.add(a,b);
			
			System.out.println("The addition result is: " + result);
			
			result = c.sub(a,b);
			System.out.println("The subtraction result is: " + result);
			
			result = c.multiply(a,b);
			System.out.println("The multiplication result is: " + result);
			
			result = c.div(a,b);*/ 
			try
			{
				result = sccalc.operate(num1,num2,operator);
				System.out.println("The result is: " + result);
			}
			catch(ArithmeticException e){
				System.out.println(e);
			}
			catch(Exception ex)
			{
				System.out.println(ex);
			}
			}
	}
}