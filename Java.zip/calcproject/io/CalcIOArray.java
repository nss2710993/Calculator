package io;
/**
This is the class 
whee actual IO starts.  It accepts two sets of numbers in comma separated form.
Then takes a comma-separated list of operators 
*/

import processor.*;
import java.util.Scanner;

public class CalcIOArray
{
	Scanner sc s= new Scanner(System.in);
	ScientificCalculator sccalc = new ScientificCalculator();
	NormalCalculator normalcalc = new NormalCalculator();
	public void startOperations()
	{
		//do operations here for taking one number at a time
	}
}