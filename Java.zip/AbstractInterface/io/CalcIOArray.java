package io;
/**
This is the class 
whee actual IO starts.  It accepts two sets of numbers in comma separated form.
Then takes a comma-separated list of operators 
*/
import utilities.*;
import processors.*;
import java.util.Scanner;
import java.io.IOException;

public class CalcIOArray extends AbstractCalcIO
{
	//Scanner sc= new Scanner(System.in);
	ScientificCalculator sccalc = new ScientificCalculator();
	NormalCalculator normalcalc = new NormalCalculator();
	
	public void startOperations() throws Exception
	{
		NormalCalculator normalcalc = AbstractCalcIO.getCalCulator();
		if(normalcalc == null)
		{
			return;
		}
		String opr,num1,num2;
		System.out.print("Input Operator: ");
		opr=sc.next();
		System.out.print("Input Number1: ");
		num1=sc.next();
		System.out.print("Input Number2: ");
		num2=sc.next();

		String [] operator,n1,n2;
		int sm,n1l,n2l,opl;
		
			  operator=opr.split(",");
			  n1=num1.split(",");
			  n2=num2.split(",");

			  opl=operator.length;
			  n1l=n1.length;
			  n2l=n2.length;

			 int small = Math.min(opl, Math.min(n1l, n2l));

	
			  int[] number1=new int[small];
			  int[] number2=new int[small];
		
			  for(int i=0;i<small;i++)
			  {
				  
				try
				{
					number1[i]=Integer.parseInt(n1[i]);
				}
				catch(Exception e)
			    {
			        System.out.println("Inputed ("+n1[i]+") Invalid Number!");
					continue;
				}
                                  
                try
				{
					number2[i]=Integer.parseInt(n2[i]);
				}
				catch(Exception e)
					{
					  System.out.println("Inputed ("+n2[i]+") Invalid Number!");
					  continue;
					}

				boolean d=normalcalc.checkOp(operator[i].charAt(0));
			    if(d==false)
				{
					  System.out.println("inputed ("+operator[i]+") Invalid Operator!");
					  continue;
				}
			  
			  try
			  {
				int res=normalcalc.operate(number1[i],number2[i],operator[i].charAt(0));
				System.out.println(number1[i]+operator[i]+number2[i]+"= "+res);
			  }
			  catch(Exception e)
			  {
				  System.out.println("Error: "+e.getMessage());
			  }
			  }

			  if(opl<n1l || opl<n2l)
		{
			System.out.println("other operation have not done for lack of Operators");
		}
		else if(opl>n1l || opl>n2l)
		{
			System.out.println("other operation have not done for lack of numbers");
		}
		  }
	}
