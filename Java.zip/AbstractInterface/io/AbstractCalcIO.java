package io;

import utilities.*;
import processors.*;
import java.util.Scanner;
import java.io.IOException;

public abstract class AbstractCalcIO
{
	Scanner sc = new Scanner(System.in); 
	
	public static NormalCalculator getCalCulator()
	{
		
		
		
		NormalCalculator calc = null;

		try
		{
			String opm = PropertyReader.getProperty("config.properties","calcmode");
			if("sc".equalsIgnoreCase(opm))
			{
			
				calc = new ScientificCalculator();
			}
			else if("nc".equalsIgnoreCase(opm))
			{
				calc = new NormalCalculator();
			}	
			else
			{
				System.out.println("Invalid Calculator type specified in properties file");
			}
		}	
		catch (IOException ex) 
		{
			System.out.println("Error Reading Properties File:" + ex.getMessage());
		}
		return calc;
		
	}
	public abstract void startOperations() throws Exception;
	
}