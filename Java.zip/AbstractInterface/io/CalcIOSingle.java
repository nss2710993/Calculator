package io;
/**
This is the class 
where actual IO starts.  But it only accepts
single number at a time and an opeatior to work
*/
import utilities.*;
import processors.*;
import java.util.Scanner;
import java.io.IOException;


public class CalcIOSingle extends AbstractCalcIO
{
	
	
	public void startOperations() throws Exception
	{
		int num1,num2,res = 0;
		NormalCalculator normalcalc = AbstractCalcIO.getCalCulator();
		if(normalcalc == null)
		{
			return;
		}
		while(true)
		{
				
				
				System.out.print("Please enter Operator or Exit (q): ");
				char operator=sc.next().charAt(0);
				if(operator=='q')
				{
					break;
				}
				boolean d=normalcalc.checkOp(operator);
				
				if(d==false)
				{
					System.out.println("Inputed ("+operator+") Invalid Operator!");
					continue;
				}
										 
				System.out.print("Enter 1st Number: ");
				while(!sc.hasNextInt())
				{
					String s=sc.next();
					System.out.println("Inputed ("+s+") Invalid Number! ");
					System.out.print("Enter 1st Number: ");
				}
					num1=sc.nextInt();
				System.out.print("Enter 2nd Number: ");
				while(!sc.hasNextInt())
				{
					String s=sc.next();
					System.out.println("Inputed ("+s+") Invalid Number! ");
					System.out.print("Enter 2nd Number: ");
				}
					num2=sc.nextInt();
								 

				try
				{	
					res=normalcalc.operate(num1,num2,operator);
					System.out.println("result= "+res);
			    }
			    catch(Exception e)
			    {
						  System.out.println("Error is: "+e.getMessage());
			    }
		}           
				 
				
	}	


		
	}
	

	/*while(true)
        {
			//Properties prop = new Properties();
			//InputStream input = null;
			
				
				//input = new FileInputStream("config.properties");
				// load a properties file
				//prop.load(input);
				// get the property value and print it out
				//String opm = prop.getProperty("calcmode");
		        //if("s".equalsIgnoreCase(opm))
		        //{
			     //   cio = new CalcIOSingle();
				//}
                //        System.out.print("Operation (+ - * / ^ %) or Exit (q): ");
                //        operator=sc.next().charAt(0);
                //        if(operator=='q')
                //        {
                //            break;
                //        }
				//if("sc".equalsIgnoreCase(opm))
		        //{
				//	ScientificCalculator sccalc = new ScientificCalculator();
                    
					
					System.out.print("Please enter Operator or Exit (q): ");
					char operator=sc.next().charAt(0);
                    if(operator=='q')
                    {
                        break;
                    }
					if(sccalc !=null)
					{	
						boolean d=sccalc.checkOp(operator);
						if(d==false)
						{
							System.out.println("Inputed ("+operator+") Invalid Operator!");
							continue;
						}
					}
					if(normalcalc !=null)
					{	
						boolean d=normalcalc.checkOp(operator);
						if(d==false)
						{
							System.out.println("Inputed ("+operator+") Invalid Operator!");
							continue;
						}
					}
                                    

                                         System.out.print("Enter 1st Number: ");
                                          while(!sc.hasNextInt())
                                          {
                                              String s=sc.next();
                                              System.out.println("Inputed ("+s+") Invalid Number! ");
                                              System.out.print("Enter 1st Number: ");
                                          }
                                          num1=sc.nextInt();
                                          
                                          
										  
                                          System.out.print("Enter 2nd Number: ");
                                          while(!sc.hasNextInt())
                                          {
                                              String s=sc.next();
                                              System.out.println("Inputed ("+s+") Invalid Number! ");
                                              System.out.print("Enter 2nd Number: ");
                                          }
                                          num2=sc.nextInt();
										 
 
                                try
                                {	
									if(sccalc !=null)
									{	
										res=sccalc.operate(num1,num2,operator);
                                    }
									if(normalcalc !=null)
									{	res=normalcalc.operate(num1,num2,operator);
									}
									System.out.println("result= "+res);
                               }
                               catch(Exception e)
                               {
                                          System.out.println("Error is: "+e.getMessage());
                               }
                               
                     }*/
					/*else if("nc".equalsIgnoreCase(opm))
					{
						NormalCalculator normalcalc = new NormalCalculator();
						System.out.print("Operation (+ - * /) or Exit (q): ");
						char operator=sc.next().charAt(0);
						if(operator=='q')
						{
							break;
						}
						boolean d=normalcalc.checkOp(operator);
						if(d==false)
						{
							System.out.println("Inputed ("+operator+") Invalid Operator!");
							continue;
						}
                                    

                                         System.out.print("Enter 1st Number: ");
                                          while(!sc.hasNextInt())
                                          {
                                              String s=sc.next();
                                              System.out.println("Inputed ("+s+") Invalid Number! ");
                                              System.out.print("Enter 1st Number: ");
                                          }
                                          num1=sc.nextInt();
                                          
                                          
										  
                                          System.out.print("Enter 2nd Number: ");
                                          while(!sc.hasNextInt())
                                          {
                                              String s=sc.next();
                                              System.out.println("Inputed ("+s+") Invalid Number! ");
                                              System.out.print("Enter 2nd Number: ");
                                          }
                                          num2=sc.nextInt();
										 
 
                               try
                               {
                                          int res=normalcalc.operate(num1,num2,operator);
                                          System.out.println("result= "+res);
                               }
                               catch(Exception e)
                               {
                                          System.out.println("Error is: "+e.getMessage());
                               }
                               
                     }
					else
					{ 	 
						System.out.println("Invalid Operation Mode Specified in Properties File");
						break;
					}*/
			
					 
                   //  System.out.println("Exit Successfully");
	


