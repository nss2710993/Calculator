import io.*;
import java.util.Scanner;

public class Main //Test Driven Development
{
	public static void main(String[] args)
	{
		CalculatorIOFile c = new CalculatorIOFile();
		c.startOperation();
	}

}