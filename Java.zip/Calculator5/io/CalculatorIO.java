package io;
import processor.*;
import java.util.Scanner;
public class CalculatorIO
{
	public void startOperation(){
	ScientificCalculator c = new ScientificCalculator();
	Scanner sc = new Scanner(System.in);
	char operator;
	double num1, num2, result;
	while (true)
	{	try
		{
		System.out.println("Enter the operator for the operation you want to do or press 'Q' for exit:");
		operator = sc.next().charAt(0);
		if (operator == 'Q') break;
		c.checkops(operator);
		}	
		catch(Exception e)
        {
			System.out.println(e.getMessage());
            continue;
		}
		System.out.println("Enter number 1: ");
		while(!sc.hasNextInt())
        {
			sc.next();
            System.out.println("Invalid Number! ");
            System.out.print("Enter 1st Number: ");
        }
		num1 = sc.nextInt();
			
		System.out.println("Enter number 2: ");
			while(!sc.hasNextInt())
            {
              sc.next();
              System.out.println("Invalid Number! ");
              System.out.print("Enter 1st Number: ");
            }
			num2 = sc.nextInt();
			
			/*result = c.add(a,b);
			
			System.out.println("The addition result is: " + result);
			
			result = c.sub(a,b);
			System.out.println("The subtraction result is: " + result);
			
			result = c.multiply(a,b);
			System.out.println("The multiplication result is: " + result);
			
			result = c.div(a,b);*/ 
			try
			{
				result = c.result1(num1,num2,operator);
				System.out.println("The result is: " + result);
			}
			catch(ArithmeticException e){
				System.out.println(e);
			}
			catch(Exception ex)
			{
				System.out.println(ex);
			}
			}
	}
	}
	