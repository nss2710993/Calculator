package processor;
public class Calculator
{
	public boolean checkops(char c) throws Exception
    {
        if(c=='+' || c=='-' || c=='*' || c=='/')
		{            
		    return true;
        }
        else return false; 
    }
	public double result1(double num1, double num2, char c )
	{
		double result = 0;
		if (c == '+') 
		{
			result = add(num1,num2);
		}
		else if (c == '-') 
		{
			result = sub(num1,num2);
		}
		else if (c == '*') 
		{
			result = multiply(num1,num2);
		}		
		else if (c == '/') 
		{
			result = div(num1,num2);
		}
		return result;
	}
	public double add(double a,double b)
	{
		return a + b;
	}
	public double sub(double a,double b)
	{
		return a - b;
	}
	public double multiply(double a,double b)
	{
		return a * b;
	}
	public double div(double a,double b)
	{
		/*if( b == 0)
		{	
			return 0;
		}*/
		return a/b;
	}

}