package processor;
public class ScientificCalculator extends Calculator
{
	@Override
    public boolean checkops(char c) throws Exception
        {
            boolean operator = super.checkops(c);
            if(operator == true)
            {
                return true;
            }
            else
            {
            if(c=='%' || c=='^'){return true;}
            else throw new Exception("Invalid Operator!");
            }
        
        }
		
	@Override
    public double result1(double num1, double num2, char c)
    {
        double result = 0;
        result = super.result1(num1, num2, c);
        if(c=='^')
        {
            result = java.lang.Math.pow(num1,num2);
        }
        else if(c=='%')
        {
            result = mod(num1,num2);
        }
        return result;
    }
	
	public double mod(double a,double b)
	{
		return a % b;
	}
	/*int power(int a,int b)
    {
        for(int num1 = 1;num1 < num2;num1++)
        {
            num1 *= num1;
        }
		return num1;
    }*/
}