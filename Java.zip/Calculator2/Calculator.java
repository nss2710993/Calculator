public class Calculator
{
	boolean operatorcheck(char c) throws Exception
    {
        if(c=='+' || c=='-' || c=='*' || c=='/')
		{            
		    return true;
        }
        else return false; 
    }
	double result1(double num1, double num2, char c )
	{
		double result = 0;
		if (c == '+') 
		{
			result = add(num1,num2);
		}
		else if (c == '-') 
		{
			result = sub(num1,num2);
		}
		else if (c == '*') 
		{
			result = multiply(num1,num2);
		}		
		else if (c == '/') 
		{
			result = div(num1,num2);
		}
		return result;
	}
	double add(double a,double b)
	{
		return a + b;
	}
	double sub(double a,double b)
	{
		return a - b;
	}
	double multiply(double a,double b)
	{
		return a * b;
	}
	double div(double a,double b)
	{
		/*if( b == 0)
		{	
			return 0;
		}*/
		return a/b;
	}

}