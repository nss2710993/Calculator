public class CalculatorChild extends Calculator
{
	@Override
    boolean operatorcheck(char c) throws Exception
        {
            boolean operator = super.operatorcheck(c);
            if(operator == true)
            {
                return true;
            }
            else
            {
            if(c=='%' || c=='^'){return true;}
            else throw new Exception("Invalid Operator!");
            }
        
        }
		
	@Override
    double result1(double num1, double num2, char c)
    {
        double result = 0;
        result = super.result1(num1, num2, c);
        if(c=='^')
        {
            result = java.lang.Math.pow(num1,num2);
        }
        else if(c=='%')
        {
            result = mod(num1,num2);
        }
        return result;
    }
	
	double mod(double a,double b)
	{
		return a % b;
	}
	/*int power(int a,int b)
    {
        for(int num1 = 1;num1 < num2;num1++)
        {
            num1 *= num1;
        }
		return num1;
    }*/
}